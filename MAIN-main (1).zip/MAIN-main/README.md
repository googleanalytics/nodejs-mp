<img src="https://avatars0.githubusercontent.com/u/4327788?s=96&v=4" alt="Google Analytics logo" title="Google Analytics" align="right" height="96" width="96"/>

## License

Apache Version 2.0

See [LICENSE](https://github.com/googleanalytics/nodejs-analyticsadmin/blob/master/LICENSE)
